from controllers.donatur_controller import DonaturController
from controllers.donasi_controller import DonasiController
from controllers.admin_controller import AdminController
from controllers.staff_controller import StaffController
from controllers.need_people_controller import NeedPeopleController


def show_main_menu():
    """Menampilkan menu utama untuk memilih koleksi."""
    print("\n=== Menu Utama ===")
    print("1. Donasi")
    print("2. Donatur")
    print("3. Admin")
    print("4. Staff")
    print("5. Need People")
    print("6. Keluar")
    return input("Pilih menu: ")


def handle_donasi():
    """Menu dan fitur untuk koleksi Donasi."""
    donasi_ctrl = DonasiController()
    while True:
        print("\n=== Menu Donasi ===")
        print("1. Tambah Donasi")
        print("2. Lihat Donasi")
        print("3. Hapus Donasi")
        print("4. Kembali ke Menu Utama")
        choice = input("Pilih menu: ")
        if choice == "1":
            donasi_ctrl.add_donasi()
        elif choice == "2":
            donasi_ctrl.view_donasi()
        elif choice == "3":
            donasi_ctrl.delete_donasi()
        elif choice == "4":
            break
        else:
            print("Pilihan tidak valid.")


def handle_donatur():
    """Menu dan fitur untuk koleksi Donatur."""
    donatur_ctrl = DonaturController()
    while True:
        print("\n=== Menu Donatur ===")
        print("1. Login Donatur")
        print("2. Registrasi Donatur")
        print("0. Kembali ke Menu Utama")
        choice = input("Pilih menu: ")
        if choice == "1":
            donatur = donatur_ctrl.login_donatur()
            if donatur:
                print(f"Data Diri Anda:\nNama: {donatur['name']}\nEmail: {donatur['email']}\nNomor Telepon: {donatur['phone']}\nTempat Tinggal: {donatur['address']}")
        elif choice == "2":
            donatur_ctrl.register_donatur()
        elif choice == "0":
            break
        else:
            print("Pilihan tidak valid.")



def handle_admin():
    """Menu dan fitur untuk koleksi Admin."""
    admin_ctrl = AdminController()
    while True:
        print("\n=== Menu Admin ===")
        print("1. Tambah Admin")
        print("2. Lihat Admin")
        print("3. Perbarui Admin")
        print("4. Hapus Admin")
        print("5. Kembali ke Menu Utama")#-
        print("0. Kembali ke Menu Utama")#+
        choice = input("Pilih menu: ")
        if choice == "1":
            admin_ctrl.add_admin()
        elif choice == "2":
            admin_ctrl.view_admin()
        elif choice == "3":
            admin_ctrl.update_admin()
        elif choice == "4":
            admin_ctrl.delete_admin()
        elif choice == "0":#+
            break
        else:
            print("Pilihan tidak valid.")


def handle_staff():
    """Menu dan fitur untuk koleksi Staff."""
    staff_ctrl = StaffController()
    staff = None

    while True:
        print("\n=== Menu Staff ===")
        print("1. Daftar sebagai Staff")
        print("2. Login sebagai Staff")
        print("3. Lihat Data Diri Staff")
        print("4. Kelola Need People")
        print("0. Kembali ke Menu Utama")

        choice = input("Pilih menu: ")

        if choice == "1":
            staff_ctrl.register_staff()
        elif choice == "2":
            staff = staff_ctrl.login_staff()
        elif choice == "3":
            if staff:
                staff_ctrl.view_staff_profile(staff)
            else:
                print("Silakan login terlebih dahulu.")
        elif choice == "4":
            if staff:
                staff_ctrl.handle_need_people()
            else:
                print("Silakan login terlebih dahulu.")
        elif choice == "0":
            break
        else:
            print("Pilihan tidak valid.")


def handle_need_people():
    """Menu dan fitur untuk koleksi Need People."""
    need_people_ctrl = NeedPeopleController()
    while True:
        print("\n=== Menu Need People ===")
        print("1. Login Need People")
        print("2. Registrasi Need People")
        print("0. Kembali ke Menu Utama")
        choice = input("Pilih menu: ")
        if choice == "1":
            need_person = need_people_ctrl.login_need_people()
            if need_person:
                print(f"Data Diri Anda:\nNama: {need_person['name']}\nEmail: {need_person['email']}\nTempat Tinggal: {need_person['address']}\nGaji Perbulan: {need_person['salary']}\nJumlah Anggota Keluarga: {need_person['family_members']}")
        elif choice == "2":
            need_people_ctrl.register_need_people()
        elif choice == "0":
            break
        else:
            print("Pilihan tidak valid.")


if __name__ == "__main__":
    while True:
        choice = show_main_menu()
        if choice == "1":
            handle_donasi()
        elif choice == "2":
            handle_donatur()
        elif choice == "3":
            handle_admin()
        elif choice == "4":
            handle_staff()
        elif choice == "5":
            handle_need_people()
        elif choice == "6":
            print("Keluar dari sistem. Terima kasih!")
            break
        else:
            print("Pilihan tidak valid.")
