from models.staff import Staff
from controllers.need_people_controller import NeedPeopleController
from utils.hashing import hash_password, verify_password


class StaffController:
    def __init__(self):
        self.staff_list = []  # Daftar staff yang sudah mendaftar
        self.need_people_ctrl = NeedPeopleController()

    def register_staff(self):
        """Mendaftarkan data diri sebagai staff."""
        print("\n=== Registrasi Staff ===")
        name = input("Nama: ")
        username = input("Username: ")
        password = hash_password(input("Password: "))
        email = input("Email: ")
        phone = input("Nomor Telepon: ")
        address = input("Tempat Tinggal: ")

        staff = Staff(name, username, password, email, phone, address)
        self.staff_list.append(staff)
        print(f"Staff '{name}' berhasil terdaftar.\n")

    def login_staff(self):
        """Login ke akun Staff."""
        print("\n=== Login Staff ===")
        username = input("Username: ")
        password = input("Password: ")

        for staff in self.staff_list:
            if staff.username == username and verify_password(staff.password, password):
                print(f"Selamat datang, {staff.name}!")
                return staff
        print("Username atau password salah!")
        return None

    def view_staff_profile(self, staff):
        """Menampilkan data diri staff."""
        print("\n=== Data Diri Staff ===")
        print(f"Nama: {staff.name}")
        print(f"Username: {staff.username}")
        print(f"Email: {staff.email}")
        print(f"Nomor Telepon: {staff.phone}")
        print(f"Tempat Tinggal: {staff.address}")

    def handle_need_people(self):
        """Mengelola data Need People."""
        while True:
            print("\n=== Menu Kelola Need People ===")
            print("1. Lihat Data Need People")
            print("2. Perbarui Data Need People")
            print("3. Hapus Data Need People")
            print("0. Kembali ke Menu Sebelumnya")

            choice = input("Pilih menu: ")

            if choice == "1":
                self.need_people_ctrl.view_need_people()
            elif choice == "2":
                self.need_people_ctrl.update_need_people()
            elif choice == "3":
                self.need_people_ctrl.delete_need_people()
            elif choice == "0":
                break
            else:
                print("Pilihan tidak valid.")
