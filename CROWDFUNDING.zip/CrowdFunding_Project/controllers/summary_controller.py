class SummaryController:
    def __init__(self, donasi_controller):
        self.donasi_controller = donasi_controller

    def donasi_summary(self):
        total = sum(donasi.amount for donasi in self.donasi_controller.donasi_list)
        print(f"\nTotal Donasi: {total}")
