from models.need_people import NeedPeople

class NeedPeopleController:
    def __init__(self):
        pass

    def register_need_people(self):
        """
        Registrasi sebagai orang tidak mampu.
        """
        print("\n=== Registrasi Orang Tidak Mampu ===")
        name = input("Nama: ")
        username = input("Username: ")
        password = input("Password: ")
        email = input("Email: ")
        address = input("Tempat Tinggal: ")
        salary = float(input("Gaji Perbulan: "))
        family_members = int(input("Jumlah Anggota Keluarga: "))

        # Cek apakah username sudah digunakan
        if NeedPeople.find_by_username(username):
            print("Username sudah digunakan. Silakan gunakan username lain.")
        else:
            NeedPeople.add_need_people(name, username, password, email, address, salary, family_members)
            print(f"Orang tidak mampu '{name}' berhasil terdaftar.")

    def login_need_people(self):
        """
        Login sebagai orang tidak mampu.
        """
        print("\n=== Login Orang Tidak Mampu ===")
        username = input("Username: ")
        password = input("Password: ")

        need_person = NeedPeople.verify_login(username, password)
        if need_person:
            print(f"Selamat datang, {need_person['name']}!")
            return need_person
        else:
            print("Username atau password salah.")
            return None
