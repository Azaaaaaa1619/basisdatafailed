from models.donatur import Donatur

class DonaturController:
    def __init__(self):
        pass

    def register_donatur(self):
        """
        Registrasi donatur baru.
        """
        print("\n=== Registrasi Donatur ===")
        name = input("Nama: ")
        username = input("Username: ")
        password = input("Password: ")
        email = input("Email: ")
        phone = input("Nomor Telepon: ")
        address = input("Tempat Tinggal: ")

        # Cek apakah username sudah digunakan
        if Donatur.find_by_username(username):
            print("Username sudah digunakan. Silakan gunakan username lain.")
        else:
            Donatur.add_donatur(name, username, password, email, phone, address)
            print(f"Donatur '{name}' berhasil terdaftar.")

    def login_donatur(self):
        """
        Login donatur.
        """
        print("\n=== Login Donatur ===")
        username = input("Username: ")
        password = input("Password: ")

        donatur = Donatur.verify_login(username, password)
        if donatur:
            print(f"Selamat datang, {donatur['name']}!")
            return donatur
        else:
            print("Username atau password salah.")
            return None
