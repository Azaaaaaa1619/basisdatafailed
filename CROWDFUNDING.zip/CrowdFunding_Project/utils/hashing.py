import hashlib
import os

def hash_password(password: str) -> str:
    """
    Menghash password menggunakan algoritma SHA-256 dengan salt.
    
    Args:
        password (str): Password yang akan dihash.
    
    Returns:
        str: Password yang sudah dihash (termasuk salt).
    """
    salt = os.urandom(16)  # Membuat salt unik
    hash_obj = hashlib.sha256(salt + password.encode('utf-8'))
    hashed_password = salt.hex() + ":" + hash_obj.hexdigest()
    return hashed_password

def verify_password(stored_password: str, provided_password: str) -> bool:
    """
    Memvalidasi password yang diberikan dengan password yang sudah dihash.
    
    Args:
        stored_password (str): Password yang sudah dihash (termasuk salt).
        provided_password (str): Password yang diberikan user.
    
    Returns:
        bool: True jika password cocok, False jika tidak.
    """
    salt, hashed_password = stored_password.split(':')
    salt = bytes.fromhex(salt)
    hash_obj = hashlib.sha256(salt + provided_password.encode('utf-8'))
    return hash_obj.hexdigest() == hashed_password
