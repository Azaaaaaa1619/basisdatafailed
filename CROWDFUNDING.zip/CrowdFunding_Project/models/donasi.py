class Donasi:
    def __init__(self, donatur_name, jenis_donasi, kategori, detail, jumlah=None):
        """
        Inisialisasi donasi.
        :param donatur_name: Nama donatur.
        :param jenis_donasi: Jenis donasi (barang, uang, makanan).
        :param kategori: Kategori untuk barang atau makanan.
        :param detail: Detail barang/makanan.
        :param jumlah: Jumlah (untuk uang atau makanan).
        """
        self.donatur_name = donatur_name
        self.jenis_donasi = jenis_donasi
        self.kategori = kategori
        self.detail = detail
        self.jumlah = jumlah

    def to_dict(self):
        """Mengubah objek Donasi menjadi dictionary untuk disimpan di database."""
        return {
            "donatur_name": self.donatur_name,
            "jenis_donasi": self.jenis_donasi,
            "kategori": self.kategori,
            "detail": self.detail,
            "jumlah": self.jumlah,
        }

    def __repr__(self):
        return f"Donasi({self.donatur_name}, {self.jenis_donasi}, {self.kategori}, {self.detail}, {self.jumlah})"
