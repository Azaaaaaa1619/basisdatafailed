# models/staff.py
class Staff:
    def __init__(self, name, email):
        self.name = name
        self.email = email

    def update(self, name, email):
        """Memperbarui informasi staff."""
        self.name = name
        self.email = email

    def __repr__(self):
        return f"Staff({self.name}, {self.email})"
