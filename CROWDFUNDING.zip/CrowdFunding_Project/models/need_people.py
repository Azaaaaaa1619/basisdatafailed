from data.lib.database import Database
from data.lib.hash import hash_password, verify_password

# Koleksi MongoDB untuk Need People
need_people_col = Database["need_people"]

class NeedPeople:
    @staticmethod
    def add_need_people(name, username, password, email, address, salary, family_members):
        """
        Menambahkan data need_people baru ke database.
        """
        hashed_password = hash_password(password)
        need_person = {
            "name": name,
            "username": username,
            "password": hashed_password,
            "email": email,
            "address": address,
            "salary": salary,
            "family_members": family_members
        }
        need_people_col.insert_one(need_person)

    @staticmethod
    def find_by_username(username):
        """
        Mencari data need_people berdasarkan username.
        """
        return need_people_col.find_one({"username": username})

    @staticmethod
    def verify_login(username, password):
        """
        Verifikasi login need_people berdasarkan username dan password.
        """
        need_person = NeedPeople.find_by_username(username)
        if need_person and verify_password(password, need_person["password"]):
            return need_person
        return None
