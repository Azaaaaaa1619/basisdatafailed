from controllers.data import dbs
from controllers.data.lib.hash import hash_password, verify_password

# Koleksi MongoDB untuk Donatur
donatur_col = dbs["donatur"]

class Donatur:
    @staticmethod
    def add_donatur(name, username, password, email, phone, address):
        """
        Menambahkan donatur baru ke database.
        """
        hashed_password = hash_password(password)
        donatur = {
            "name": name,
            "username": username,
            "password": hashed_password,
            "email": email,
            "phone": phone,
            "address": address
        }
        donatur_col.insert_one(donatur)

    @staticmethod
    def find_by_username(username):
        """
        Mencari donatur berdasarkan username.
        """
        return donatur_col.find_one({"username": username})

    @staticmethod
    def verify_login(username, password):
        """
        Verifikasi login donatur berdasarkan username dan password.
        """
        donatur = Donatur.find_by_username(username)
        if donatur and verify_password(password, donatur["password"]):
            return donatur
        return None
