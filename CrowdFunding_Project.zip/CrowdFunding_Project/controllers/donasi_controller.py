from models.donasi import Donasi
from controllers.data.dbs import Database

donasi_col = Database["donasi"]

class DonasiController:
    def __init__(self):
        self.donasi_list = []

    def add_donasi(self, donatur_names):
        """Menambahkan donasi baru."""
        if not donatur_names:
            print("Tidak ada donatur terdaftar. Harap tambahkan donatur terlebih dahulu.")
            return

        print("\n=== Tambah Donasi ===")
        print("Pilih Donatur:")
        for i, name in enumerate(donatur_names, start=1):
            print(f"{i}. {name}")
        index = int(input("Pilih nomor donatur: ")) - 1

        if 0 <= index < len(donatur_names):
            donatur_name = donatur_names[index]
            print("\nJenis Donasi:")
            print("1. Barang")
            print("2. Uang")
            print("3. Makanan")
            jenis_donasi = input("Pilih jenis donasi: ")

            if jenis_donasi == "1":
                kategori = input("Kategori Barang (pakaian, sepatu, buku, seragam, dll): ")
                detail = input("Detail Barang: ")
                donasi = Donasi(donatur_name, "Barang", kategori, detail)
            elif jenis_donasi == "2":
                jumlah = float(input("Jumlah Uang yang Didonasikan: "))
                donasi = Donasi(donatur_name, "Uang", "Uang", "Donasi Uang", jumlah)
            elif jenis_donasi == "3":
                print("Kategori Makanan:")
                print("1. Siap Saji")
                print("2. Bahan Mentah (sembako)")
                kategori_makanan = input("Pilih kategori makanan: ")
                if kategori_makanan == "1":
                    kategori = "Makanan Siap Saji"
                elif kategori_makanan == "2":
                    kategori = "Bahan Mentah"
                else:
                    print("Kategori tidak valid.")
                    return
                detail = input("Detail Makanan: ")
                jumlah = int(input("Jumlah Makanan: "))
                donasi = Donasi(donatur_name, "Makanan", kategori, detail, jumlah)
            else:
                print("Jenis donasi tidak valid.")
                return

            self.donasi_list.append(donasi)
            donasi_col.insert_one(donasi.to_dict())
            print("Donasi berhasil ditambahkan.")
        else:
            print("Nomor donatur tidak valid.")

    def view_donasi(self):
        """Melihat daftar donasi."""
        print("\n=== Daftar Donasi ===")
        for donasi in donasi_col.find():
            print(donasi)

    def delete_donasi(self):
        """Menghapus donasi berdasarkan ID."""
        self.view_donasi()
        donasi_id = input("Masukkan ID Donasi yang ingin dihapus: ")
        result = donasi_col.delete_one({"_id": donasi_id})
        if result.deleted_count > 0:
            print("Donasi berhasil dihapus.")
        else:
            print("ID Donasi tidak ditemukan.")
