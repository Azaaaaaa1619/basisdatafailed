from pymongo import MongoClient

class Database:
    def __init__(self, uri="mongodb://localhost:27017/", db_name="CrowdFunding"):
        self.client = MongoClient(uri)
        self.db = self.client[db_name]
        self.collections = {
            "admin": self.db["Admin"],
            "donasi": self.db.Donasi,
            "donatur": self.db.Donatur,
            "need_people": self.db.Need_People,
            "staff": self.db.Staff,
            "type": self.db.Type
            
        }

    def get_collection(self, collection_name):
        return self.collections.get(collection_name, None)

    def insert_data(self, collection_name, data):
        collection = self.get_collection(collection_name)
        if collection:
            collection.insert_one(data)
            print(f"Data berhasil dimasukkan ke dalam koleksi {collection_name}.")
        else:
            print(f"Koleksi {collection_name} tidak ditemukan.")
    
    def find_data(self, collection_name, query=None):
        collection = self.get_collection(collection_name)
        if collection:
            query = query or {}
            return collection.find(query)
        else:
            print(f"Koleksi {collection_name} tidak ditemukan.")
            return None

    def update_data(self, collection_name, query, update_data):
        collection = self.get_collection(collection_name)
        if collection:
            collection.update_one(query, {"$set": update_data})
            print(f"Data berhasil diperbarui dalam koleksi {collection_name}.")
        else:
            print(f"Koleksi {collection_name} tidak ditemukan.")

    def delete_data(self, collection_name, query):
        collection = self.get_collection(collection_name)
        if collection:
            collection.delete_one(query)
            print(f"Data berhasil dihapus dari koleksi {collection_name}.")
        else:
            print(f"Koleksi {collection_name} tidak ditemukan.")
