from models.admin import Admin
from controllers.data.dbs import Database
from data.lib.hash import hash_password, verify_password

admin_col = Database["admin"]
need_people_requests_col = Database["need_people_requests"]
need_people_col = Database["need_people"]

class AdminController:
    def __init__(self):
        self.logged_in_admin = None

    def login(self):
        """Admin login."""
        print("\n=== Login Admin ===")
        username = input("Username: ")
        password = input("Password: ")

        admin_data = admin_col.find_one({"username": username})
        if admin_data and verify_password(password, admin_data["hashed_password"]):
            self.logged_in_admin = Admin(admin_data["username"], admin_data["hashed_password"])
            print(f"Selamat datang, {self.logged_in_admin.username}!")
        else:
            print("Login gagal. Username atau password salah.")

    def add_admin(self):
        """Menambahkan admin baru (hanya bisa dilakukan oleh admin yang login)."""
        if not self.logged_in_admin:
            print("Harap login terlebih dahulu.")
            return

        print("\n=== Tambah Admin Baru ===")
        username = input("Username: ")
        password = input("Password: ")
        hashed_password = hash_password(password)

        admin = Admin(username, hashed_password)
        admin_col.insert_one(admin.to_dict())
        print(f"Admin '{username}' berhasil ditambahkan.")

    def manage_need_people_requests(self):
        """Mengelola pendaftaran dari Need People."""
        if not self.logged_in_admin:
            print("Harap login terlebih dahulu.")
            return

        print("\n=== Permintaan Pendaftaran Need People ===")
        requests = list(need_people_requests_col.find())
        if not requests:
            print("Tidak ada permintaan pendaftaran.")
            return

        for i, req in enumerate(requests, start=1):
            print(f"\n{i}. {req}")
            print(f"1. Setujui")
            print(f"2. Tolak")
            choice = input("Pilih aksi: ")

            if choice == "1":
                need_people_col.insert_one(req)
                need_people_requests_col.delete_one({"_id": req["_id"]})
                print("Pendaftaran disetujui.")
            elif choice == "2":
                need_people_requests_col.delete_one({"_id": req["_id"]})
                print("Pendaftaran ditolak.")
            else:
                print("Pilihan tidak valid.")
